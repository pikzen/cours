double plus (double first, double second) {
	return first + second;
}

double moins(double first, double second) {
	return first - second;
}

double mult (double first, double second) {
	return first * second;
}
