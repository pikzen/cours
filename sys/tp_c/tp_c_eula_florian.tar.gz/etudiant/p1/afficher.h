#pragma once

void afficher	(char [], double, double, double);