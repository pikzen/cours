#include "pluginmanager.h"

extern "C" {

  // fonction d'initialisation d'un plugin
  void
  init_(plugin_manager * pm);

};
