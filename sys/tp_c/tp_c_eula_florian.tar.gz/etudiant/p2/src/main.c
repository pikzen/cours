#include "pluginmanager.h"

int main(int argc, char** argv)
{
	int flag_askforfolder = (argc == 1); // Si aucun argument n'a été passé, on demandera le dossier
	plugin_manager pluginmanager;

}