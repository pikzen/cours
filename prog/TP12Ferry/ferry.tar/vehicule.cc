#include <iostream>
#include "vehicule.h"

//------------------------------------------------------------------------
// classe Vehicule
//------------------------------------------------------------------------

// constructeur

// destructeur

// longueur d'un véhicule

// nombre de personnes dans le véhicule

// opérateur d'affichage
