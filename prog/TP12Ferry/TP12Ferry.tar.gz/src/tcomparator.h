#pragma once

class TComparator {
public:
	bool operator()(const Vehicule* first, const Vehicule* second);
};